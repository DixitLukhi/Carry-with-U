import React from 'react'

const NotFound = () =>
  <div className="error-img">
    {/* <h3 className="text-white">404 page not found</h3> */}

  </div>
export default NotFound;