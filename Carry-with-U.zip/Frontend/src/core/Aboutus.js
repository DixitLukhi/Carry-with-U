import React from 'react'

export default function Aboutus() {
    return (
        <div>
            <h1 className="text-white">Dixit Lukhi</h1>
        </div>
    )
}
